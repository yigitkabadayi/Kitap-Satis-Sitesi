// Wrap all code in an IIFE to avoid redeclaration errors
(function() {
    // Handle form switching on login/register page
    const loginToggle = document.getElementById('loginToggle');
    const registerToggle = document.getElementById('registerToggle');
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');

    if (loginToggle && registerToggle && loginForm && registerForm) {
        loginToggle.addEventListener('click', () => {
            loginForm.classList.remove('hidden');
            registerForm.classList.add('hidden');
            loginToggle.classList.add('active');
            registerToggle.classList.remove('active');
        });

        registerToggle.addEventListener('click', () => {
            registerForm.classList.remove('hidden');
            loginForm.classList.add('hidden');
            registerToggle.classList.add('active');
            loginToggle.classList.remove('active');
        });

        // Initial state: show login form and activate login button
        loginToggle.classList.add('active');
        registerForm.classList.add('hidden');
    }
    // Register form submit
    if (registerForm) {
        registerForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            const username = registerForm.querySelector('input[placeholder="Kullanıcı Adı"]').value;
            const email = registerForm.querySelector('input[placeholder="E-posta"]').value;
            const password = registerForm.querySelector('input[placeholder="Şifre"]').value;
            try {
                const response = await fetch('http://localhost:3000/api/register', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ username, email, password })
                });
                const result = await response.json();
                if (result.success) {
                    alert('Kayıt başarılı! Giriş yapabilirsiniz.');
                    loginToggle.click();
                } else {
                    alert(result.error || 'Kayıt başarısız!');
                }
            } catch (err) {
                alert('Bir hata oluştu.');
            }
        });
    }
    // Login form submit
    if (loginForm) {
        loginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            const email = loginForm.querySelector('input[placeholder="E-posta"]').value;
            const password = loginForm.querySelector('input[placeholder="Şifre"]').value;
            try {
                const response = await fetch('http://localhost:3000/api/login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email, password })
                });
                const result = await response.json();
                if (result.success) {
                    localStorage.setItem('username', result.username);
                    localStorage.setItem('fullname', result.fullname);
                    window.location.href = 'index.html';
                } else {
                    alert(result.error || 'Giriş başarısız!');
                }
            } catch (err) {
                alert('Bir hata oluştu.');
            }
        });
    }
})();