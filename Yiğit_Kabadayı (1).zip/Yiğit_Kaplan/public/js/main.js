// DOM Elements
const booksGrid = document.querySelector('.books-grid');
const cartItems = document.querySelector('.cart-items');
const loginForm = document.getElementById('loginForm');
const featuredList = document.querySelector('.featured-list');
const registerForm = document.getElementById('registerForm');

// Cart state
let cart = [];
let allBooks = [];
const savedUsername = localStorage.getItem('username');
// Eğer fullname varsa onu kullan, yoksa username'i kullan
const savedFullname = localStorage.getItem('fullname');

// Kullanıcıya özel sepet anahtarı
function getCartKey() {
    return savedUsername ? `cart_${savedUsername}` : 'cart_guest';
}

// Sepeti localStorage'dan yükle
function loadCart() {
    const cartStr = localStorage.getItem(getCartKey());
    cart = cartStr ? JSON.parse(cartStr) : [];
}
// Sepeti localStorage'a kaydet
function saveCart() {
    localStorage.setItem(getCartKey(), JSON.stringify(cart));
}

// Fetch books from API
async function fetchBooks() {
    try {
        const response = await fetch('http://localhost:3000/api/books');
        const books = await response.json();
        allBooks = books; // Kitapları global değişkene ata
        if (booksGrid) {
            displayBooks(books);
        }
        if (featuredList) {
            displayFeaturedBooks(books.slice(0, 8)); // İlk 8 kitabı öne çıkanlar olarak göster
        }
    } catch (error) {
        console.error('Error fetching books:', error);
    }
}

// Display books in the grid (for books.html)
function displayBooks(books) {
    booksGrid.innerHTML = books.map(book => `
        <div class="book-card">
            <img src="${book.image_url || 'https://via.placeholder.com/300x400'}" alt="${book.title}">
            <div class="book-info">
                <h3>${book.title}</h3>
                <p>${book.author}</p>
                <p class="price">${book.price} TL</p>
                <button onclick="addToCart(${book.id})">Sepete Ekle</button>
            </div>
        </div>
    `).join('');
}

// Display featured books (for index.html)
function displayFeaturedBooks(books) {
    featuredList.innerHTML = books.map(book => `
        <div class="book-card">
            <img src="${book.image_url || 'https://via.placeholder.com/300x400'}" alt="${book.title}">
            <div class="book-info">
                <h3>${book.title}</h3>
                <p>${book.author}</p>
                <p class="price">${book.price} TL</p>
                <button onclick="addToCart(${book.id})">Sepete Ekle</button>
            </div>
        </div>
    `).join('');
}

// Add book to cart
function addToCart(bookId) {
    const book = allBooks.find(b => b.id === bookId);
    if (book) {
        cart.push(book);
        saveCart();
        updateCart();
        alert('Kitap sepete başarılı bir şekilde eklendi!');
    }
}

// Update cart display
function updateCart() {
    if (!cartItems) return;
    const cartEmpty = document.querySelector('.cart-empty');
    const cartActions = document.querySelector('.cart-actions');
    if (cart.length === 0) {
        cartItems.innerHTML = '';
        cartItems.style.display = 'none';
        if (cartEmpty) {
            cartEmpty.classList.remove('hidden');
            cartEmpty.style.display = 'flex';
        }
        if (cartActions) cartActions.style.display = 'none';
        return;
    }
    cartItems.style.display = 'block';
    cartItems.innerHTML = cart.map(item => `
        <div class="cart-item-card">
            <img src="${item.image_url || 'https://via.placeholder.com/80x120?text=Kitap'}" alt="${item.title}" class="cart-item-img">
            <div class="cart-item-info">
                <h4>${item.title}</h4>
                <p class="cart-item-author">${item.author}</p>
                <p class="cart-item-price">${item.price} TL</p>
                <button onclick="removeFromCart(${item.id})">Kaldır</button>
            </div>
        </div>
    `).join('');
    if (cartEmpty) {
        cartEmpty.classList.add('hidden');
        cartEmpty.style.display = 'none';
    }
    if (cartActions) cartActions.style.display = 'flex';
}

// Remove book from cart
function removeFromCart(bookId) {
    cart = cart.filter(item => item.id !== bookId);
    saveCart();
    updateCart();
    showNotification('Kitap sepetten kaldırıldı!');
}

// Show notification
function showNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// User navbar logic
const userNav = document.getElementById('userNav');
const loginNav = document.getElementById('loginNav');
const navbarUsername = document.getElementById('navbarUsername');
const userDropdown = document.querySelector('.user-dropdown');

function showUserNav(username) {
    if (userNav && loginNav) {
        userNav.classList.remove('hidden');
        if (loginNav.parentNode) {
            loginNav.parentNode.removeChild(loginNav);
        }
        // Eğer fullname varsa onu göster
        if (savedFullname) {
            navbarUsername.textContent = savedFullname;
        } else {
            navbarUsername.textContent = username;
        }
    }
}
function hideUserNav() {
    if (userNav && loginNav) {
        userNav.classList.add('hidden');
        loginNav.classList.remove('hidden');
    }
}
// Dropdown toggle (sadece kullanıcı adına tıklanınca açılır)
if (userNav && navbarUsername) {
    navbarUsername.addEventListener('click', function(e) {
        e.stopPropagation();
        userDropdown.classList.toggle('show');
    });
    // Navbarın diğer kısmına tıklanırsa dropdown kapanır
    document.addEventListener('click', function(e) {
        if (!userNav.contains(e.target)) {
            userDropdown.classList.remove('show');
        }
    });
}
// Logout
const logoutBtn = document.getElementById('logoutBtn');
if (logoutBtn) {
    logoutBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        localStorage.removeItem('username');
        hideUserNav();
        userDropdown.classList.remove('show');
        window.location.reload(); // Sayfayı yenile
    });
}
// On page load, check login state
if (savedUsername) {
    showUserNav(savedUsername);
} else {
    hideUserNav();
}
// Sepeti yükle ve varsa göster
loadCart();
if (cartItems) {
    updateCart();
}

// Initialize the page
document.addEventListener('DOMContentLoaded', () => {
    fetchBooks();
});

// Sepeti Temizle
const clearCartBtn = document.getElementById('clearCartBtn');
if (clearCartBtn) {
    clearCartBtn.addEventListener('click', function() {
        cart = [];
        saveCart();
        updateCart();
        alert('Sepetiniz temizlendi!');
    });
}
// Satın Almayı Tamamla (Ödeme modalı aç)
const checkoutBtn = document.getElementById('checkoutBtn');
const paymentModal = document.getElementById('paymentModal');
const closeModalBtn = document.getElementById('closeModalBtn');
const payBtn = document.getElementById('payBtn');
const totalPriceSpan = document.getElementById('totalPrice');
if (checkoutBtn && paymentModal && totalPriceSpan) {
    checkoutBtn.addEventListener('click', function() {
        // Toplam fiyatı hesapla
        const total = cart.reduce((sum, item) => sum + Number(item.price), 0);
        totalPriceSpan.textContent = total.toFixed(2);
        paymentModal.classList.remove('hidden');
    });
}
if (closeModalBtn && paymentModal) {
    closeModalBtn.addEventListener('click', function() {
        paymentModal.classList.add('hidden');
    });
}
if (payBtn && paymentModal) {
    payBtn.addEventListener('click', function() {
        // Basit kontrol: inputlar dolu mu?
        const inputs = paymentModal.querySelectorAll('.payment-input');
        let valid = true;
        inputs.forEach(input => { if (!input.value.trim()) valid = false; });
        if (!valid) {
            alert('Lütfen tüm ödeme bilgilerini doldurun!');
            return;
        }
        // Ödeme başarılı
        // Başarı mesajı göster
        let successMsg = paymentModal.querySelector('.payment-success');
        if (!successMsg) {
            successMsg = document.createElement('div');
            successMsg.className = 'payment-success';
            paymentModal.querySelector('.modal-content').appendChild(successMsg);
        }
        successMsg.textContent = 'Ödeme işlemi tamamlandı! Siparişiniz alınmıştır.';
        // Sepeti temizle
        cart = [];
        saveCart();
        updateCart();
        // Modalı 2 saniye sonra kapat
        setTimeout(() => {
            paymentModal.classList.add('hidden');
            successMsg.textContent = '';
            // Inputları temizle
            inputs.forEach(input => input.value = '');
        }, 2000);
    });
}