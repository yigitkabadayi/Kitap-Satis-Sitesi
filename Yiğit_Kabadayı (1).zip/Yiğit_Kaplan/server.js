const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');

const app = express();
const port = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

// Database setup
const db = new sqlite3.Database('bookstore.db', (err) => {
    if (err) {
        console.error('Error opening database:', err);
    } else {
        console.log('Connected to SQLite database');
        createTables();
    }
});

// Create tables
function createTables() {
    db.run(`CREATE TABLE IF NOT EXISTS books (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        author TEXT NOT NULL,
        price REAL NOT NULL,
        description TEXT,
        image_url TEXT,
        stock INTEGER DEFAULT 0
    )`, insertInitialBooks);

    db.run(`CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        total_amount REAL NOT NULL,
        status TEXT DEFAULT 'pending',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )`);
}

// Insert initial data
function insertInitialBooks() {
    db.get('SELECT COUNT(*) AS count FROM books', (err, row) => {
        if (err) {
            console.error('Error checking book count:', err.message);
            return;
        }
        // Sadece tablo boşsa ekle
        if (row.count === 0) {
            const stmt = db.prepare('INSERT INTO books (title, author, price, description, image_url, stock) VALUES (?, ?, ?, ?, ?, ?)');
            stmt.run('1984', 'George Orwell', 25.00, 'Distopik bir klasik', 'https://m.media-amazon.com/images/I/41MDF2hTDzL._SY445_SX342_.jpg', 10);
            stmt.run('Cesur Yeni Dünya', 'Aldous Huxley', 22.50, 'Farklı bir distopya', 'https://m.media-amazon.com/images/I/31CilzjWYaL._SY445_SX342_.jpg', 15);
            stmt.run('Fahrenheit 451', 'Ray Bradbury', 20.00, 'Kitapların yakıldığı bir dünya', 'https://m.media-amazon.com/images/I/312ZmeDr3EL._SY445_SX342_.jpg', 8);
            stmt.run('Otostopçunun Galaksi Rehberi', 'Douglas Adams', 30.00, 'Mizahi bilim kurgu', 'https://m.media-amazon.com/images/I/51SBI9kK5EL._SY342_.jpg', 12);
            stmt.run('Dune', 'Frank Herbert', 35.00, 'Epik bilim kurgu', 'https://m.media-amazon.com/images/I/71oO1E-XPuL._SY466_.jpg', 7);
            stmt.finalize();
            console.log('Initial books inserted.');
        } else {            
            console.log('Books table already populated.');
        }
    });
}                                                   

// Routes
app.get('/api/books', (req, res) => {
    db.all('SELECT * FROM books', [], (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json(rows);
    });
});

// Register endpoint
app.post('/api/register', (req, res) => {
    const { username, email, password } = req.body;
    if (!username || !email || !password) {
        return res.status(400).json({ error: 'Tüm alanlar zorunludur.' });
    }
    const stmt = db.prepare('INSERT INTO users (username, email, password) VALUES (?, ?, ?)');
    stmt.run(username, email, password, function(err) {
        if (err) {
            if (err.message.includes('UNIQUE')) {
                return res.status(409).json({ error: 'Kullanıcı adı veya e-posta zaten kayıtlı.' });
            }
            return res.status(500).json({ error: 'Kayıt sırasında bir hata oluştu.' });
        }
        res.json({ success: true, userId: this.lastID });
    });
    stmt.finalize();
});

// Login endpoint
app.post('/api/login', (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
        return res.status(400).json({ error: 'Tüm alanlar zorunludur.' });
    }
    db.get('SELECT * FROM users WHERE email = ? AND password = ?', [email, password], (err, user) => {
        if (err) {
            return res.status(500).json({ error: 'Giriş sırasında bir hata oluştu.' });
        }
        if (!user) {
            return res.status(401).json({ error: 'E-posta veya şifre hatalı ya da kayıtlı değilsiniz.' });
        }
        res.json({ success: true, username: user.username, fullname: user.username });
    });
});

// Start server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});